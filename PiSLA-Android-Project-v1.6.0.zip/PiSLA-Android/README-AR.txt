PiSLA Android — الإصدار 1.7.0
============================

هذا مشروع Android Studio يغلّف نسخة PiSLA HTML داخل WebView، ويعمل دون اتصال بالإنترنت في الوظائف المحلية.

إنشاء APK عبر Android Studio:
1. ثبّت Android Studio بإصدار حديث.
2. افتح مجلد PiSLA-Android بوصفه مشروعًا موجودًا.
3. وافق على تنزيل Gradle وAndroid SDK عند الطلب.
4. من قائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5. الملف الناتج: app/build/outputs/apk/debug/app-debug.apk

يمكن أيضًا رفع المجلد إلى مستودع GitHub، ثم تشغيل سير العمل Build PiSLA APK من تبويب Actions وتنزيل artifact باسم PiSLA-Android-APK.

مهم:
- هذه نسخة Debug غير موقّعة للنشر في Google Play.
- قبل النشر أو التوزيع الواسع، يلزم إنشاء توقيع Release واختبار جميع وظائف الاستيراد والتصدير على جهاز Android فعلي.
- وظائف فتح الملفات تدعم منتقي الملفات في Android. تنزيلات Blob أو ميزات التصدير الخاصة بالمتصفح قد تحتاج تكييفًا إضافيًا حسب سلوك WebView.
