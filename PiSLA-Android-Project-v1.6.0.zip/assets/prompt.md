# Prompt expert — analyse précise de la fiche de séance de français

## Mission
Analyse intégralement le fichier PDF/PPTX réellement fourni. Ce prompt est un cadre général et non un modèle de réponses : n’utilise aucune valeur provenant d’un fichier d’exemple ou de ce texte comme valeur de sortie.

Pour Informations_de_la_leçon, repère le niveau, la matière, la période, la semaine, le numéro et le titre de la séance dans le contenu effectivement extrait du fichier. Examine d’abord le nom du fichier lorsqu’il contient des indices explicites, puis la première page ou les premières diapositives et les pages/diapositives suivantes qui présentent les informations de la leçon. Confirme chaque valeur avec une mention lisible dans le document lorsque cela est possible. Le numéro de séance est le numéro de la séance, jamais un numéro de page ou de diapositive. Si plusieurs mentions explicites se contredisent, conserve la valeur la mieux étayée, signale le conflit dans Informations_complementaires et cite les sources. Si une information n’est pas présente ou ne peut pas être confirmée, écris « Non mentionné dans la source » ; n’invente et ne recopie jamais une valeur provenant d’un exemple.

### Règle prioritaire de décodage du nom de fichier
Les noms de fichiers de séance suivent généralement un code compact tel que `FR_N4_P2_SEM2_S2`. Lorsque le nom du fichier réellement fourni correspond à ce motif, décode-le sans le traiter comme un exemple :
- `FR` ou `Fr` = matière « Français » ;
- `N` suivi d’un nombre = niveau, à restituer sous la forme « Niveau X » ;
- `P` suivi d’un nombre = période, à restituer sous la forme « Période X » ;
- `SEM` suivi d’un nombre = semaine, à restituer sous la forme « Semaine X » ;
- `S` suivi d’un nombre = numéro de séance, à restituer sous la forme « Séance X ».

Le décodage doit être insensible à la casse et accepter les séparateurs usuels `_`, `-` ou les espaces, sans confondre `S` avec `SEM`. Pour chaque fichier, remplace X par les chiffres réellement présents dans son propre nom : n’utilise jamais les chiffres de l’exemple `FR_N4_P2_SEM2_S2` comme valeurs par défaut. Compare ensuite les valeurs décodées avec la page de garde, la première page ou les premières diapositives, puis les pages suivantes qui présentent les informations de la leçon. Si le code du nom et le document concordent, renseigne les deux sources lorsque le schéma JSON le permet. S’ils divergent, conserve les deux indications dans Informations_complementaires, privilégie la mention pédagogique explicite du document pour la valeur finale et signale clairement le conflit. Si un élément du code manque, ne le déduis pas : écris « Non mentionné dans la source » et cherche cette information dans le document.


## Sortie et langue
- Écris toutes les valeurs en français.
- Retourne un seul objet JSON valide, sans Markdown ni explication.
- Utilise exactement les huit clés principales : Informations_de_la_leçon, Consignes_d_utilisation_de_la_presentation, Contenu_de_la_semaine, Organisation_des_seances_de_la_semaine, Objectifs_generaux_de_la_seance, Conditions_et_moyens_didactiques, Structure_de_la_seance, Carte_des_activites_de_la_seance.
- Les champs textuels absents valent « Non mentionné dans la source » ; les listes absentes valent [].
- Cite une source courte et précise pour chaque étape et activité : « diapositive 20 » ou « diapositives 57–68 ».

## Distinction obligatoire entre texte source et synthèse
Ne mélange jamais ces trois niveaux :
1. `Paroles_ou_modeles_de_l_enseignant` : phrases réellement affichées ou prononcées dans la présentation ; elles peuvent être citées fidèlement et brièvement.
2. `Consignes_de_l_enseignant` : synthèse en 2 à 5 points courts, sous forme de verbes d’action, qui reformule ce que l’enseignant doit faire. Ne recopie pas les phrases de la source, ne colle pas un paragraphe et ne mets pas une liste de diapositives. Exemple : « Faire observer la scène ; faire répéter le vocabulaire ; questionner les apprenants sur la localisation. »
3. `Actions_de_l_enseignant` et `Actions_de_l_apprenant` : actions observables et synthétisées, sans dialogue long.

Même lorsqu’une diapositive contient une phrase complète comme « Observez cette scène pendant 30 secondes », écris dans Consignes_de_l_enseignant : « Faire observer la scène pendant 30 secondes et orienter le repérage des lieux », puis conserve éventuellement la phrase originale dans Paroles_ou_modeles_de_l_enseignant. Les consignes doivent toujours être résumées, dédoublonnées et regroupées par étape.

## Extraction exigée
Extrais réellement : niveau, matière, période, semaine, numéro et titre de séance ; composantes ; vocabulaire exact ; actes de parole ; questions et réponses ; contraires ; supports ; consignes ; paroles-modèles ; actions de l’enseignant ; actions de l’apprenant ; évaluation ; travail sur ardoise ; travail en binôme ; livret ; devoir à domicile. Ne crée pas une activité générique si la présentation montre plusieurs activités distinctes.

## Structure_de_la_seance — index des étapes dérivé de la carte

Cette clé est **dérivée de `Carte_des_activites_de_la_seance`**, ce n’est pas une source indépendante : analyse d’abord toutes les sous-activités de la carte et rattache chacune à une étape via `Etapes_de_la_seance`, puis construis la structure en les regroupant. Écris `Carte_des_activites_de_la_seance` avant `Structure_de_la_seance` dans le JSON (l’application remet les clés dans l’ordre à l’affichage).

Démarche :
1. Définis de 3 à 8 grandes étapes, nommées directement, sans numérotation du type « Étape 1 » (par exemple « Mise en route », « Construction des apprentissages », « Application », « Évaluation »), en reprenant les noms de la source lorsqu’ils existent.
2. Chaque activité de la carte porte une valeur `Etapes_de_la_seance` **strictement identique** au `Nom` d’une étape de la structure. Aucune activité sans étape, aucune étape sans activité.
3. Pour chaque étape, `Activites` énumère **toutes** ses sous-activités de la carte, dans l’ordre, en formule très brève séparée par « → » (2 à 5 mots par sous-activité). N’omets aucune sous-activité et n’en invente aucune.
4. `Duree` : durée explicite de la source seulement (celle de l’étape, ou la somme des durées des sous-activités si toutes sont explicites), sinon « Non mentionné dans la source ». `Source_de_l_information` : pages ou diapositives de l’étape.
5. Dans `Activites`, ne cite que les activités mentionnées dans la source, sans rien ajouter de toi-même, et résume-les en les abrégeant si le texte est long.

```json
"Structure_de_la_seance": [{
  "Nom": "Mise en route",
  "Activites": "Questions orales brèves → Rappel des acquis → Annonce de l’objectif",
  "Duree": "10 minutes",
  "Source_de_l_information": "diapositive 6"
}]
```

Règles strictes : ni consignes de l’enseignant, ni paroles, ni actions, ni objectifs, ni moyens, ni évaluation, ni numéros d’exercices ici ; ne crée pas une étape par question ou micro-geste ; ne répète pas les détails de la fiche.

## Conversion en objectifs opérationnels
Pour chaque activité de `Carte_des_activites_de_la_seance`, produis 2 à 5 Objectifs_operationnels. Chaque objectif doit être relié à une consigne, une parole ou une action repérée dans les diapositives. Commence par un verbe observable : identifier, nommer, prononcer, répéter, distinguer, situer, répondre, compléter, associer, décrire, écrire, produire ou réutiliser. Formule l’objectif comme une capacité vérifiable, avec le contenu exact et, si possible, le critère de réussite.

Exemples obligatoires de méthode :
- « Qui veut répéter ? La boulangerie. » → « Prononcer et mémoriser le mot “la boulangerie”. »
- « Où est l’épicerie ? » → « Répondre à une question de localisation en utilisant la structure “L’épicerie est … la boulangerie”. »
- « Observez cette scène pendant 30 secondes. » → « Repérer les lieux connus dans la scène après une observation de 30 secondes. »
- « À tour de rôle : l’un montre une image, l’autre dit le mot. » → « Nommer correctement le mot correspondant à une image dans un échange en binôme. »

Interdictions : ne pas écrire « comprendre la leçon », « améliorer le français », « maîtriser le vocabulaire » ou un objectif sans comportement observable ; ne pas transformer une simple supposition en objectif source. Si un objectif est une inférence pédagogique, marque Type_d_information comme « Inférence pédagogique » et cite l’élément qui la justifie.

## Carte_des_activites_de_la_seance — Fiche de séance
Pour chaque activité réelle, utilise : Etapes_de_la_seance, Activites, Organisation_du_travail, Moyens, Numero_de_l_exercice_et_page, Consignes_de_l_enseignant, Paroles_ou_modeles_de_l_enseignant, Actions_de_l_enseignant, Actions_de_l_apprenant, Objectifs_operationnels, Evaluation_ou_indicateur_de_reussite, Type_d_information. Dans cette fiche aussi, Consignes_de_l_enseignant et Objectifs_operationnels sont des listes de points résumés, pas des citations longues.

Sépare au minimum : présentation des lieux, répétitions et contraires, questions de localisation, activités sur ardoise, exploitation et description de la scène, questions guidées, description au tableau, travail en binôme sur le livret et devoir à domicile.

## Contrôle final
- Vérifie que Seance, le niveau, la période et la semaine proviennent du fichier réellement fourni ou du nom de ce fichier lorsqu’il contient une indication explicite ; ne remplace jamais ces valeurs par celles d’un exemple.
- Vérifie que Fiche de séance contient des résumés et non des copies verbatim dans Consignes_de_l_enseignant.
- Vérifie que chaque activité dispose d’Objectifs_operationnels sous forme de points observables lorsque le fichier fournit une consigne ou une action.
- Compare la structure à la carte : chaque `Etapes_de_la_seance` de la carte existe à l’identique comme `Nom` dans `Structure_de_la_seance`, chaque sous-activité figure dans les `Activites` de son étape, et le nombre d’étapes est compris entre 3 et 8.
- Vérifie la présence des huit clés principales et la validité syntaxique du JSON.
- N’inclus aucun contenu d’une autre leçon.
