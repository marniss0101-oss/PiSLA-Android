@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (echo يجب تثبيت Node.js LTS من https://nodejs.org/ & pause & exit /b 1)
call npm install
if errorlevel 1 (echo فشل تثبيت الاعتماديات. تحقق من اتصال الإنترنت. & pause & exit /b 1)
call npm run dist
if errorlevel 1 (echo فشل البناء. راجع رسالة الخطأ أعلاه. & pause & exit /b 1)
echo.
echo اكتمل البناء. راجع مجلد release.
pause
