@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo يجب تثبيت Node.js LTS اولا من https://nodejs.org/
  pause
  exit /b 1
)
start "PiSLA PWA" cmd /k "node server.cjs"
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:4173"
