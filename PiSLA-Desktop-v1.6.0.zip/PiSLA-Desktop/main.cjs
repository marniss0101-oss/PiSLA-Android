const { app, BrowserWindow, Menu, shell, dialog } = require('electron');
const path = require('node:path');

const isDev = !app.isPackaged;
function createWindow() {
  const win = new BrowserWindow({
    width: 1440, height: 940, minWidth: 900, minHeight: 650,
    title: 'PiSLA | محلل PPT التعليم الصريح',
    autoHideMenuBar: true,
    backgroundColor: '#eef5f8',
    icon: path.join(__dirname, 'assets', 'icon.ico'),
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true,
      webSecurity: true
    }
  });
  win.loadFile(path.join(__dirname, 'index.html'));
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('https://') || url.startsWith('http://')) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (event, url) => {
    if (!url.startsWith('file://')) event.preventDefault();
  });
  if (isDev) win.webContents.openDevTools({ mode: 'detach' });
}

app.whenReady().then(() => {
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    { label: 'ملف', submenu: [
      { label: 'إعادة تحميل التطبيق', accelerator: 'Ctrl+R', click: () => BrowserWindow.getFocusedWindow()?.reload() },
      { label: 'طباعة', accelerator: 'Ctrl+P', click: () => BrowserWindow.getFocusedWindow()?.webContents.print({ printBackground: true }) },
      { type: 'separator' }, { role: 'quit', label: 'خروج' }
    ] },
    { label: 'عرض', submenu: [ { role: 'resetZoom', label: 'الحجم الافتراضي' }, { role: 'zoomIn', label: 'تكبير' }, { role: 'zoomOut', label: 'تصغير' }, { type: 'separator' }, { role: 'togglefullscreen', label: 'ملء الشاشة' } ] },
    { label: 'مساعدة', submenu: [ { label: 'حول PiSLA', click: () => dialog.showMessageBox({ type: 'info', title: 'حول PiSLA', message: 'PiSLA | محلل PPT التعليم الصريح', detail: 'الإصدار 1.8.1\nتطبيق مكتبي يعمل محليًا على الحاسوب.' }) } ] }
  ]));
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
