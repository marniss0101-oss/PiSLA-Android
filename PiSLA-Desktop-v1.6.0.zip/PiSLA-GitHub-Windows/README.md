# PiSLA — Windows build

This repository package wraps the PiSLA HTML application in Electron and builds two Windows x64 outputs through GitHub Actions:

- **NSIS installer** — installable application with desktop and Start Menu shortcuts.
- **Portable executable** — run without installing.

## Build on GitHub

1. Create or open the `PiSLA` repository on GitHub.
2. Upload the contents of this folder to the repository root, preserving `.github/workflows/build-windows.yml`.
3. Open **Actions** → **Build PiSLA Windows**.
4. Select **Run workflow** (or push to `main` / `master`).
5. When the run succeeds, open the run and download the `PiSLA-Windows-v1.8.0` artifact.

The artifact contains the installer and portable executable.

## Build locally

Requires Node.js 22 and npm:

```bash
npm install
npm run dist:win
```

Outputs are written to `dist/`.

## Application data

The application loads `app/index.html` locally. Browser local storage is used by the HTML app for its saved settings/data and is managed by Electron's normal application profile.
