PiSLA Android Cloud Build Kit

This kit lets you build a debug APK using GitHub Actions from an Android phone, without installing Android Studio locally.

Start with: اقرأني-لإنشاء-APK-من-الهاتف.txt

Contents:
- PiSLA-Android-Project-v1.6.0.zip : Android source project
- build-apk.yml : workflow file to create at .github/workflows/build-apk.yml in your GitHub repository
- .github/workflows/build-apk.yml : same workflow stored in its intended path

No APK binary is included. GitHub Actions must run the build first.
